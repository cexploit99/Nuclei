# THANKS

- https://github.com/dop251/goja - Pure Go Javascript VM used by nuclei JS layer.
- https://github.com/gogap/gojs-tool - Inspiration for code generation used in JS Libraries addition.
- https://github.com/ropnop/kerbrute - Kerberos Module of JS layer
- https://github.com/praetorian-inc/fingerprintx - A lot of Network Protocol fingerprinting functionality is used from `fingerprintx` package. 
- https://github.com/zmap/zgrab2 - Used for SMB and SSH protocol handshake Metadata gathering.

A lot of other Go based libraries are used in the javascript layer. Thanks goes to the creators and maintainers.